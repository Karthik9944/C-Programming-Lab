#include <stdio.h>
int main()
{
    float a,b,p;
    scanf("%f%f",&a,&b);
    p=a*b;
    printf("%.2f",p);
    return 0;
}
